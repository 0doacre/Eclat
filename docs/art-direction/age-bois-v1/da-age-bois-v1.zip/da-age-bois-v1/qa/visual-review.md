# Contrôle visuel du lot v1

Contrôle réalisé dans une galerie navigateur à facteur d'échelle 1, avec chaque fichier affiché sur fond ivoire et ardoise, à 96, 48 et 32 pixels CSS. La capture est `contact-sheet.png`. Les 114 images d'affichage chargent correctement ; les largeurs réelles de 32 et 48 px ont été vérifiées. La galerie n'a pas de débordement horizontal à 1280 px.

## Constats

- La palette, le traitement à l'encre et les volumes sont cohérents dans l'ensemble du lot.
- Les ressources brutes et les fabrications correspondantes restent distinctes : fibres / corde, bois / manche, pierre / percuteur.
- L'épieu conserve sa pointe sombre en bois, sans ajouter de tête en silex ni en métal. L'archet est bien un dispositif de friction pour le feu, sans flèche.
- Les trois installations ont des silhouettes différentes : cabane, claie et carrière. Leurs détails secondaires s'atténuent au petit format.
- Les sources de récolte représentent un arbre, des plantes vivantes et un affleurement ; elles ne réutilisent pas les images des matières dans la Réserve.
- Aucun rectangle de papier ou cadre n'apparaît autour des sujets sur les deux fonds testés.

## Points d'attention pour l'intégration

- **Charbon sur fond sombre :** c'est l'illustration au contraste le plus faible, surtout à 32 px. Prévoir un emplacement légèrement plus clair dans ce thème et vérifier le résultat en jeu. Garder la couleur du charbon ; éviter une recoloration globale ou un halo.
- **Archet à 32 px :** conserver un libellé accessible et un nom visible là où l'utilisateur doit identifier une recette. La mécanique exacte du dispositif ne peut pas se lire dans une icône aussi petite.
- **Manche et épieu :** conserver les proportions et la diagonale ; ne pas étirer les images dans les petites cases.
- Les tiges et petites feuilles des sources ont vocation à être montrées plus grandes dans le Domaine que les objets dans la Réserve. Le test à 32 px donne leur limite de lecture, pas leur taille recommandée pour une cible tactile.

Le contrôle porte sur les illustrations et leur affichage isolé. Les contrastes définitifs, les états du jeu, les animations, les performances et le cache hors ligne seront vérifiés par Gemini lors de l'intégration.
