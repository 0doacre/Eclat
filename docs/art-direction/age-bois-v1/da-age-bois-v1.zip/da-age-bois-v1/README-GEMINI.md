# Éclat — Premier lot du Carnet du Semeur

Ce dossier contient les illustrations candidates v1 de l'**Âge du Bois**, l'âge d'indice `0` dans les données du jeu. Génération par l'outil intégré imagegen. Les PNG maîtres sont livrés séparément, sans découpe de planche nécessaire. Le moteur et l'interface du jeu n'ont pas été modifiés pour ce lot.

## Contenu

- 14 ressources et fabrications principales : bois, fibres, pierre, manche, corde, panier, archet à feu, feu de camp, charbon, épieu, cabane, torche, claie de séchage et carrière à main.
- 2 outils supplémentaires de la preview : percuteur de pierre et établi aménagé.
- 3 sources de récolte distinctes pour le Domaine : arbre, plantes à fibres et affleurement de pierre.
- Les curiosités `quart_coeur` et `anneau_lourd`, les lieux d'exploration et les âges suivants sont hors de ce premier lot. Conserver leurs représentations existantes.

`manifest.json` donne les identifiants du jeu, les chemins, les dimensions, les empreintes SHA-256 et les usages. `preview.html` affiche chaque illustration sur un fond clair et un fond sombre, à 96, 48 et 32 pixels réels. `qa/contact-sheet.png` est une capture de cette galerie, pas une source à découper. `qa/inspection.json` contient les contrôles de dimensions et de canal alpha.

`qa/visual-review.md` décrit le contrôle visuel et les points d'attention. En particulier, l'emplacement du charbon devra être légèrement plus clair sur le thème sombre pour garder une lecture confortable au petit format.

## Direction à préserver

Encre brun-noir et lavis de matière désaturé, lumière venant du haut à gauche. Les sujets sont isolés sur fond transparent ; aucun papier, cadre, texte ou halo de rareté n'est intégré aux illustrations. Conserver les couleurs de matière : la couleur de l'âge intervient dans les états de l'interface.

Les images de source et d'objet ont des fonctions différentes : `source_bois` est un arbre à récolter, tandis que `bois` est la matière dans la Réserve. Même distinction pour les plantes à fibres et la pierre. Ne pas remplacer une source par son objet par défaut.

Les petits formats conservent la silhouette et les principales masses ; les détails des maîtres s'atténuent naturellement. Valider la lecture dans les vrais écrans, notamment pour l'archet, la claie et les outils en bois. La galerie ne remplace pas un test des interactions ni des contrastes avec tous les thèmes du jeu.

## Intégration proposée à Gemini

1. Garder ces PNG maîtres intacts. Exporter les variantes nécessaires pour l'affichage, en PNG ou WebP avec alpha, après comparaison visuelle. Les maîtres ne sont pas optimisés pour le téléchargement dans le jeu.
2. Ajouter un registre d'illustrations basé sur les identifiants du manifeste, avec un contexte distinct pour les objets et les sources de récolte. Respecter les objets inconnus, les recettes non découvertes et les différences entre atelier classique et équipé.
3. **`js/icons.js` est un fichier généré.** Mettre à jour les sources ou le générateur si nécessaire, ou introduire un registre séparé ; ne pas éditer ce fichier à la main en risquant de perdre le travail à la prochaine génération.
4. Brancher d'abord ce lot dans le mode « Vivant ». Garder le repli SVG existant pour les illustrations non encore produites, les pictogrammes d'interface et les autres modes. Éviter tout filtre CSS qui recolore uniformément les illustrations.
5. Utiliser `object-fit: contain`, conserver leurs proportions et prévoir une marge commune dans les emplacements. Les sujets allongés, comme l'épieu et le manche, ne doivent pas être étirés pour remplir un carré.
6. Raccorder les retours de frappe et les états sans peindre les effets dans l'image. Une animation de transformation doit préserver une cible tactile stable.
7. Ajouter seulement les variantes réellement utilisées au cache hors ligne, puis recalculer le service worker. Vérifier le poids total avant de cacher les grands maîtres.
8. Vérifier les thèmes clair et sombre, les affichages à 32/48 px et les petits écrans, puis lancer les tests du jeu et les contrôles de non-régression.

## Prompts et reproduction

Le prompt complet d'un asset est le contenu de `prompt-commun.txt`, suivi de `SUBJECT: ` et du champ `subject` de sa ligne dans `asset-specs.json`. Les générations originales sont issues de l'outil intégré imagegen, sans reconstitution SVG ni retouche raster locale. Le script d'inspection lit les PNG sans les réenregistrer ; la galerie les redimensionne seulement à l'affichage.
