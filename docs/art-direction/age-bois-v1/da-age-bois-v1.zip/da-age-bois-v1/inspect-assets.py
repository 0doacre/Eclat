"""Inspection uniquement : ne transforme ni ne réenregistre les images."""
import hashlib
import json
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parent
specs = json.loads((root / "asset-specs.json").read_text(encoding="utf-8"))
reports = []
for spec in specs:
    path = root / spec["file"]
    if not path.exists():
        reports.append({"id": spec["id"], "missing": True})
        continue
    with Image.open(path) as source:
        image = source.convert("RGBA")
        alpha = image.getchannel("A")
        histogram = alpha.histogram()
        width, height = image.size
        # Seuil pour ignorer les quelques traces presque transparentes éventuelles.
        bbox = alpha.point(lambda a: 255 if a > 8 else 0).getbbox()
        margin = min(bbox[0], bbox[1], width - bbox[2], height - bbox[3]) if bbox else 0
        reports.append({
            "id": spec["id"], "file": spec["file"], "name": spec["name"],
            "kind": spec["kind"], "profile": spec.get("profile", "both"),
            "width": width, "height": height, "originalMode": source.mode,
            "hasAlpha": "A" in source.getbands(),
            "transparentFraction": round(histogram[0] / (width * height), 4),
            "alphaRange": alpha.getextrema(), "subjectBounds": bbox,
            "minimumMargin": margin,
            "transparentCorners": all(alpha.getpixel(p) == 0 for p in [(0, 0), (width - 1, 0), (0, height - 1), (width - 1, height - 1)]),
            "bytes": path.stat().st_size,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
        })
(root / "qa" / "inspection.json").write_text(json.dumps(reports, ensure_ascii=False, indent=2), encoding="utf-8")
for report in reports:
    print(json.dumps(report, ensure_ascii=False))
