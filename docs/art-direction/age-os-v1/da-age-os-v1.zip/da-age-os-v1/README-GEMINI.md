# Éclat — Âge de l'Os, lot d'illustrations v1

Ce lot poursuit la direction **Le Carnet du Semeur** : contour d'encre brun-noir, lavis naturels désaturés, lumière venant du haut à gauche et silhouettes lisibles. Génération avec l'outil intégré imagegen. Les PNG sont fournis séparément, avec alpha, sans papier ni texte incorporé.

## Périmètre du deuxième lot

L'Âge de l'Os est l'âge d'indice `1`. Le lot comporte **16 nouvelles illustrations** :

- 13 objets communs : `os`, `cuir`, `aiguille`, `laniere`, `colle_os`, `arc`, `fronde`, `outre`, `pic_os`, `collets`, `tunique`, `encre`, `cuir_1` ;
- 1 outil propre à la preview équipée : `racloir_os` ;
- 2 sources de récolte de la Plaine : `source_os` et `source_cuir`.

Les curiosités `de_vingt` et `fouet_cuir`, les lieux d'exploration et les âges suivants ne font pas partie de ce lot.

L'identifiant `cuir` correspond à la matière nommée **Peau** dans les données. Le nom du fichier ne doit pas renommer cet objet. Le cerf de `source_cuir` représente la faune de la Plaine comme repère visuel ; il ne crée ni nouvelle espèce, ni nouvelle règle de chasse ou de rendement.

## Fichiers de référence

- `manifest.json` : identifiants, usages, profils, dimensions et empreintes SHA-256 des nouveaux PNG.
- `preview.html` : toutes les nouvelles illustrations à 96, 48 et 32 px sur fonds clair et sombre.
- `continuite.html` : comparaison avec quatre illustrations du lot Bois ; les images de `references-bois/` sont uniquement des références déjà livrées.
- `qa/inspection.json` : canal alpha, bornes du sujet et marges.
- `qa/visual-review.md` : observations au petit format et points à vérifier dans le jeu.
- `prompt-commun.txt` et `asset-specs.json` : prompt complet = prompt commun suivi de `SUBJECT: ` et du champ `subject` de l'asset.

## Choix de dessin à conserver

L'os brut conserve ses articulations ; les aiguilles sont polies et percées ; le racloir est une lame large en os ; le pic associe une tête claire à un manche en bois. Ces silhouettes doivent rester différentes au petit format.

Les lanières sont des bandes plates de peau, distinctes des brins torsadés de la corde. La fronde est une poche à deux lanières, pas un lance-pierre en Y. L'arc de chasse est un arc simple, distinct de l'archet à feu du premier âge.

Les contenants de colle et d'encre restent primitifs : ils ne doivent pas introduire une bouteille de verre ou des pièces métalliques d'un âge ultérieur. Les illustrations donnent une forme à la matière ; elles ne modifient pas les ingrédients des recettes.

La source d'os est un petit groupe d'ossements animaux dans les herbes. La source de peau est un animal vivant. Les matières dans la Réserve restent représentées par un os isolé et une peau séchée. Conserver ces contextes séparés.

## Intégration à réaliser par Gemini

1. Conserver les PNG maîtres intacts. Exporter les variantes web utiles en PNG ou WebP avec alpha, puis comparer les silhouettes et les contrastes aux originaux.
2. Étendre le registre `js/illustrations.js` et les dossiers `assets/carnet/items/` et `assets/carnet/sources/` déjà utilisés pour le premier lot. Préserver les choix de l'intégration en cours de l'interface dessinée.
3. Utiliser les cartes du manifeste pour distinguer objets, sources et outil propre à la preview. Respecter les découvertes et les objets encore inconnus.
4. Garder `object-fit: contain` et les proportions, notamment pour l'arc et les aiguilles. Les petites icônes accompagnent des noms lisibles ; les sources peuvent être montrées plus grandes dans le Domaine.
5. Préserver les couleurs de matière. Les accents d'âge et les états appartiennent à l'interface ; aucun filtre uniforme ne doit transformer la peau et l'os en aplats identiques.
6. Garder les replis SVG pour les éléments non couverts et les autres modes du jeu. `js/icons.js` reste un fichier généré : ne pas le modifier manuellement en contournant son générateur.
7. Mettre dans le cache uniquement les variantes réellement consommées par le jeu, puis recalculer le service worker. Exclure les maîtres, les références du premier âge, les captures et l'archive de travail.
8. Vérifier les thèmes clair/sombre, les écrans mobiles, les textes longs, les sources et les états du jeu. Lancer les tests et parcours navigateur adaptés après intégration.

Le contrôle de cette livraison porte sur les illustrations et leur présentation isolée. La validation des interactions, de la compression et du cache sera faite dans le jeu par Gemini.
