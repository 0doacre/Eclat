# Revue visuelle — Âge de l’Os v1

Les 16 PNG originaux ont été examinés individuellement puis sur la planche `contact-sheet.png`, sur fonds clair et sombre. La comparaison `continuite-bois-os.png` rapproche os/bois, lanières/corde, arc/archet et outre/panier.

## Résultat

La continuité avec le Bois est satisfaisante : encre brune, lavis ocre et ivoire, volumes simples et absence de papier incorporé. Les matières restent distinctes sans dépendre de la couleur de l’âge. Les aiguilles, le pic et le racloir se distinguent de l’os brut ; la peau plate se distingue de la tunique et de l’outre. La colle ambrée et l’encre noire conservent des contenus différents. Le bord clair du bol d’encre maintient sa lecture sur fond sombre.

Les lanières plates ne ressemblent pas à la corde tressée. L’arc de chasse et l’archet à feu du Bois ont des silhouettes distinctes. La fronde conserve une poche et deux attaches. La fosse de tannage présente une silhouette d’installation, distincte des matières portables.

Les sources montrent des ossements animaux et une bête vivante dans les herbes, sans blessures ni effets lumineux. Leur contexte les distingue des objets de la Réserve.

## Limites à conserver en tête lors de l’intégration

À 32 px, le chas des aiguilles, la corde de l’arc et le déclencheur des collets perdent du détail. Les silhouettes restent utilisables avec leur nom ; éviter d’en faire des commandes isolées sans libellé. Les sources bénéficient d’un affichage plus grand dans le Domaine. Garder les proportions et ne pas recadrer les sujets longs pour remplir une case carrée.

## Contrôles réalisés

- 16 fichiers présents, canal alpha et pixels totalement transparents ; marge minimale du sujet : 19 px dans les originaux.
- Empreintes SHA-256 des maîtres dans `manifest.json`.
- Galerie : 96 chargements d’images réussis ; tailles réelles 32 et 48 px ; pas de débordement horizontal au format mobile contrôlé.
- Continuité : 24 chargements réussis ; tailles réelles 32 et 48 px ; pas de débordement à 320 px.

Les PNG sont les sorties intactes de l’outil imagegen intégré. Les captures proviennent du rendu navigateur des galeries. Ces vérifications ne remplacent pas la validation des exports WebP, des états de découverte, des interactions et du cache dans le jeu après intégration.
