"use strict";
const fs = require("fs"), path = require("path"), assert = require("assert/strict");
const ROOT = path.resolve(__dirname, "..");
const specs = JSON.parse(fs.readFileSync(path.join(ROOT, "asset-specs.json"), "utf8"));
const inspection = JSON.parse(fs.readFileSync(path.join(ROOT, "qa", "inspection.json"), "utf8"));
assert.equal(inspection.length, specs.length);
for (const a of inspection) {
  assert.ok(!a.missing, "Fichier manquant : " + a.id);
  assert.ok(a.hasAlpha && a.alphaRange[0] === 0 && a.alphaRange[1] === 255, "Canal alpha incomplet : " + a.id);
  assert.ok(a.transparentFraction > .15, "Fond insuffisamment transparent : " + a.id);
  assert.ok(a.minimumMargin > 0, "Sujet coupé au bord : " + a.id);
}
const manifest = {
  schemaVersion: 1,
  collection: "eclat-carnet-semeur-age-os-v1",
  status: "candidats-pour-integration",
  age: { index: 1, id: "os", name: "Âge de l’Os" },
  generator: "imagegen intégré",
  format: "PNG RGBA — maîtres non optimisés pour la diffusion web",
  preview: "preview.html",
  visualReview: "qa/visual-review.md",
  excluded: ["de_vingt", "fouet_cuir", "lieux d'exploration", "âges suivants"],
  maps: {
    items: Object.fromEntries(specs.filter(s => s.kind === "item").map(s => [s.id, s.file])),
    harvestSources: Object.fromEntries(specs.filter(s => s.kind === "source").map(s => [s.resource, s.file])),
    previewOnly: specs.filter(s => s.profile === "preview").map(s => s.id),
  },
  assets: specs.map(s => {
    const a = inspection.find(a => a.id === s.id);
    return { id: s.id, name: s.name, kind: s.kind, gameResource: s.resource || null, profile: s.profile || "both", file: s.file, width: a.width, height: a.height, alpha: true, bytes: a.bytes, sha256: a.sha256, subjectBounds: a.subjectBounds };
  }),
  checks: { count: inspection.length, allHaveAlpha: true, allHaveTransparentPixels: true, allHavePositiveSubjectMargins: true, details: "qa/inspection.json" },
  notes: ["Les PNG maîtres sont intacts.", "Un canal alpha très faible peut subsister hors de la silhouette ; consulter le rapport avant une optimisation des contours.", "Les versions web doivent être exportées et comparées visuellement avant ajout au cache hors ligne.", "Les sources de récolte et les icônes d'objets utilisent des contextes distincts."]
};
fs.writeFileSync(path.join(ROOT, "manifest.json"), JSON.stringify(manifest, null, 2));
console.log(JSON.stringify({ assets: manifest.assets.length, bytes: manifest.assets.reduce((n, a) => n + a.bytes, 0), previewOnly: manifest.maps.previewOnly }));
