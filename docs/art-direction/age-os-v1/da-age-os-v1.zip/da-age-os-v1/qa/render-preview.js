"use strict";
// Mise en page et capture uniquement : les PNG sources restent intacts.
const fs = require("fs"), path = require("path"), http = require("http"), assert = require("assert/strict");
const { chromium } = require(process.env.PW || "playwright");
const ROOT = path.resolve(__dirname, "..");
const allSpecs = JSON.parse(fs.readFileSync(path.join(ROOT, "asset-specs.json"), "utf8"));
const specs = process.env.PARTIAL ? allSpecs.filter(s => fs.existsSync(path.join(ROOT, s.file))) : allSpecs;
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const cards = specs.map(s => '<article><header><b>' + esc(s.name) + '</b><code>' + esc(s.id) + '</code></header><div class="comparison">' + ["light", "dark"].map(theme => '<section class="' + theme + '"><img width="96" height="96" src="' + s.file + '" alt="' + esc(s.name) + '"><div class="mini"><span><img width="48" height="48" src="' + s.file + '" alt="">48 px</span><span><img width="32" height="32" src="' + s.file + '" alt="">32 px</span></div></section>').join("") + '</div><footer>' + (s.kind === "source" ? "Source de récolte · Domaine" : "Objet · Réserve / fabrication") + (s.profile === "preview" ? " · preview" : "") + '</footer></article>').join("");
const html = '<!doctype html><html lang="fr"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Éclat · Âge de l’Os · Assets v1</title><style>*{box-sizing:border-box}body{margin:0;padding:28px;background:#e8e2d6;color:#302d27;font:14px/1.4 system-ui,sans-serif}h1{margin:0 0 4px;font:30px Georgia,serif}p{margin:0 0 20px}.grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}article{background:#f8f5ed;border:1px solid #c2b8a5;border-radius:8px;overflow:hidden}header{padding:10px 12px;display:flex;justify-content:space-between;gap:8px;align-items:center}code{font-size:10px;color:#766747}.comparison{display:grid;grid-template-columns:1fr 1fr}section{padding:8px;display:flex;align-items:center;flex-direction:column;gap:6px}.light{background:#f1e9d8}.dark{background:#252c30;color:#d8dbd8}img{display:block;object-fit:contain;flex:none}.mini{height:68px;display:flex;align-items:flex-end;gap:18px}.mini span{display:flex;flex-direction:column;align-items:center;font-size:10px;gap:4px}footer{padding:7px 12px;color:#665d4e;font-size:11px}body>footer{padding:16px 0}@media(max-width:900px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:500px){body{padding:12px}.grid{grid-template-columns:1fr}}</style><h1>Éclat — Âge de l’Os</h1><p>16 illustrations candidates v1 · Encre et lavis · Fonds clair et sombre · Dimensions réelles de rendu : 96, 48 et 32 px.</p><main class="grid">' + cards + '</main><footer>Les images originales restent intactes. Cette galerie permet de comparer la transparence, les silhouettes et les petits formats avant intégration.</footer></html>';
fs.writeFileSync(path.join(ROOT, "preview.html"), html);
const server = http.createServer((req, res) => {
  const f = path.resolve(ROOT, "." + new URL(req.url, "http://localhost").pathname.replace(/\/$/, "/preview.html"));
  if (!f.startsWith(ROOT + path.sep)) return res.writeHead(403).end();
  fs.readFile(f, (err, data) => { if (err) return res.writeHead(404).end(); res.setHeader("Content-Type", f.endsWith(".png") ? "image/png" : "text/html; charset=utf-8"); res.end(data); });
});
(async () => {
  await new Promise(r => server.listen(0, "127.0.0.1", r));
  const browser = await chromium.launch({ headless: true, ...(process.env.CHROMIUM ? { executablePath: process.env.CHROMIUM } : {}) });
  try {
    const page = await browser.newPage({ viewport: { width: 1280, height: 1000 }, deviceScaleFactor: 1 });
    await page.goto("http://127.0.0.1:" + server.address().port + "/");
    await page.waitForFunction(() => [...document.images].every(i => i.complete && i.naturalWidth > 0));
    const result = await page.evaluate(() => ({
      images: document.images.length,
      real32: [...document.querySelectorAll('img[width="32"]')].every(i => i.getBoundingClientRect().width === 32),
      real48: [...document.querySelectorAll('img[width="48"]')].every(i => i.getBoundingClientRect().width === 48),
      overflow: document.documentElement.scrollWidth > innerWidth,
    }));
    assert.equal(result.images, specs.length * 6); assert.ok(result.real32 && result.real48 && !result.overflow);
    await page.screenshot({ path: path.join(ROOT, "qa", "contact-sheet.png"), fullPage: true });
    fs.writeFileSync(path.join(ROOT, "qa", "browser-check.json"), JSON.stringify(result, null, 2));
    console.log(JSON.stringify(result));
  } finally { await browser.close(); server.close(); }
})().catch(e => { console.error(e); server.close(); process.exitCode = 1; });
