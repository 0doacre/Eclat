"use strict";
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),{pathToFileURL}=require('url');
const {chromium}=require(process.env.PW||'playwright'),ROOT=path.resolve(__dirname,'..');
(async()=>{
  const browser=await chromium.launch({headless:true,...(process.env.CHROMIUM?{executablePath:process.env.CHROMIUM}:{})});
  try{
    const p=await browser.newPage({viewport:{width:1080,height:1200},deviceScaleFactor:1}),errors=[];
    p.on('pageerror',e=>errors.push(e.message));await p.goto(pathToFileURL(path.join(ROOT,'continuite.html')).href);
    await p.waitForFunction(()=>[...document.images].every(i=>i.complete&&i.naturalWidth>0));
    const report=await p.evaluate(()=>({images:document.images.length,real32:[...document.querySelectorAll('img[width="32"]')].every(i=>i.getBoundingClientRect().width===32),real48:[...document.querySelectorAll('img[width="48"]')].every(i=>i.getBoundingClientRect().width===48)}));
    assert.equal(report.images,24);assert.ok(report.real32&&report.real48);assert.equal(errors.length,0,errors.join(';'));
    await p.screenshot({path:path.join(__dirname,'continuite-bois-os.png'),fullPage:true});
    await p.setViewportSize({width:320,height:900});report.mobileOverflow=await p.evaluate(()=>document.documentElement.scrollWidth>innerWidth);assert.ok(!report.mobileOverflow);
    fs.writeFileSync(path.join(__dirname,'continuity-check.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
