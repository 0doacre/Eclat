"use strict";
const fs=require('fs'),path=require('path'),crypto=require('crypto'),assert=require('assert/strict');
const ROOT=path.resolve(__dirname,'..'),original=path.resolve(ROOT,'../da-age-bois-v1/assets');
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
for(const name of fs.readdirSync(path.join(ROOT,'assets/illustrations'))){const candidate=path.join(ROOT,'assets/illustrations',name);assert.equal(hash(candidate),hash(path.join(original,name)),name+' a été modifié');}
const entries=[];
function walk(dir){for(const item of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,item.name);if(item.isDirectory())walk(file);else if(item.name!=='manifest.json')entries.push({file:path.relative(ROOT,file).replaceAll('\\','/'),bytes:fs.statSync(file).size,sha256:hash(file)});}}
walk(ROOT);entries.sort((a,b)=>a.file.localeCompare(b.file));
const manifest={collection:'eclat-interface-dessinee-v1',status:'prototype-autonome',gameEngineConnected:false,entry:'index.html',moodboard:'moodboard-interface-dessinee-v1.png',brief:'README-GEMINI.md',components:'composants.json',originalIllustrationsUnchanged:true,files:entries};
fs.writeFileSync(path.join(ROOT,'manifest.json'),JSON.stringify(manifest,null,2));console.log(JSON.stringify({files:entries.length,illustrations:8,svg:entries.filter(e=>e.file.endsWith('.svg')).length,bytes:entries.reduce((n,e)=>n+e.bytes,0)}));
