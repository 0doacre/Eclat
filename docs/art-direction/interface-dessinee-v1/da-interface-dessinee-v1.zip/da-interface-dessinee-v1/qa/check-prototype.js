"use strict";
const fs=require('fs'),path=require('path'),assert=require('assert/strict'),{pathToFileURL}=require('url');
const {chromium}=require(process.env.PW||'playwright');
const ROOT=path.resolve(__dirname,'..');
(async()=>{
  const browser=await chromium.launch({headless:true,...(process.env.CHROMIUM?{executablePath:process.env.CHROMIUM}:{})});
  let count=0;const check=(v,message)=>{assert.ok(v,message);count++;};const shots=[];
  try{
    for(const width of [320,390,980])for(const dark of [false,true]){
      const context=await browser.newContext({viewport:{width,height:1100},deviceScaleFactor:1,reducedMotion:'reduce'}),p=await context.newPage(),errors=[];
      p.on('pageerror',e=>errors.push(e.message));
      await p.goto(pathToFileURL(path.join(ROOT,'index.html')).href);await p.evaluate(()=>document.fonts.ready);
      await p.waitForFunction(()=>[...document.images].every(i=>i.complete&&i.naturalWidth>0));
      if(dark)await p.locator('#themeButton').click();
      const overflow=()=>p.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
      check(!await overflow(),'menu contenu '+width+'/'+dark);
      check(await p.locator('#resumeButton').evaluate(el=>el.getBoundingClientRect().height>=44),'bouton principal tactile');
      check(await p.locator('#tab-jeu').evaluate(el=>el.getBoundingClientRect().height>=44),'onglet tactile');
      check(await p.locator('#ambienceCheck').evaluate(el=>el.getBoundingClientRect().width>=44),'case tactile');
      const prefix=(dark?'sombre':'clair')+'-'+width;
      if(width===390){const shot='menu-'+prefix+'.png';await p.locator('#gamePage').screenshot({path:path.join(__dirname,shot)});shots.push(shot);}
      await p.locator('#resumeButton').click();
      check(await p.locator('#domainPage').isVisible(),'reprise ouvre le Domaine');
      await p.locator('[data-harvest="bois"]').click();
      check(await p.locator('[data-stock="bois"]').innerText()==='123','récolte locale une seule fois');
      check((await p.locator('#status').innerText()).includes('simulation locale'),'simulation explicitée');
      check(!await overflow(),'Domaine contenu '+width+'/'+dark);
      if(width===390){const shot='domaine-'+prefix+'.png';await p.locator('#gamePage').screenshot({path:path.join(__dirname,shot)});shots.push(shot);}
      await p.locator('#backToMenu').click();await p.locator('#tab-jeu').focus();await p.keyboard.press('ArrowRight');
      check(await p.locator('#tab-affichage').getAttribute('aria-selected')==='true','navigation clavier des onglets');
      check(await p.locator('#panel-affichage').isVisible()&&!await p.locator('#panel-jeu').isVisible(),'un panneau à la fois');
      await p.locator('#largeTextDisplayCheck').check();
      check(await p.evaluate(()=>document.documentElement.dataset.large==='true'),'grand texte fonctionnel');
      check(!await overflow(),'grand texte contenu '+width+'/'+dark);
      await p.locator('#largeTextDisplayCheck').uncheck();await p.locator('#tab-audio').click();
      await p.locator('#ambienceVolume').focus();await p.keyboard.press('End');
      check(await p.locator('#volumeValue').innerText()==='100 %','valeur audio actualisée');
      await p.locator('#tab-jeu').click();await p.locator('#saveButton').click();
      check((await p.locator('#status').innerText()).includes('Aucune partie'),'sauvegarde sans prétendre enregistrer une partie');
      await p.locator('#helpButton').click();check(await p.locator('#helpDialog').isVisible(),'aide ouvrable');
      await p.locator('#helpDialog button').click();check(!await p.locator('#helpDialog').isVisible(),'aide fermable');
      await p.locator('[data-view="composants"]').click();check(await p.locator('#componentSheet').isVisible(),'composants accessibles');
      await p.locator('#progressDemo').focus();await p.keyboard.press('End');
      check(await p.locator('.ink-progress').getAttribute('aria-valuenow')==='100','progression accessible actualisée');
      check(!await overflow(),'composants contenus');
      if(width===980){await p.locator('#progressDemo').evaluate(el=>{el.value=45;el.dispatchEvent(new Event('input',{bubbles:true}));el.blur();});const shot='composants-'+prefix+'.png';await p.locator('#componentSheet').screenshot({path:path.join(__dirname,shot)});shots.push(shot);}
      check(errors.length===0,errors.join('; '));await context.close();
    }
    const report={checks:count,widths:[320,390,980],themes:['light','dark'],shots,nativeControls:true,gameEngineConnected:false};
    fs.writeFileSync(path.join(__dirname,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
