"use strict";
// Les sources SVG restent séparées et éditables. Leurs masques sont embarqués
// dans le CSS pour fonctionner aussi à l'ouverture locale du prototype.
const fs=require('fs'),path=require('path'),ROOT=path.resolve(__dirname,'..'),UI=path.join(ROOT,'assets/ui');
for(const [name,w,h] of [['frame-ink.svg',240,240],['frame-chalk.svg',240,240],['button-ink.svg',200,64],['button-chalk.svg',200,64]]){
  const p=path.join(UI,name);let svg=fs.readFileSync(p,'utf8');
  if(!/<svg[^>]*\bwidth=/.test(svg))svg=svg.replace('<svg ','<svg width="'+w+'" height="'+h+'" ');
  fs.writeFileSync(p,svg);
}
const mask=name=>'url("data:image/svg+xml,'+encodeURIComponent(fs.readFileSync(path.join(UI,name),'utf8').trim())+'")';
const p=path.join(ROOT,'prototype.css');let css=fs.readFileSync(p,'utf8').replace(/\n\/\* Embedded drawing masks \*\/[\s\S]*$/,'');
css=css.replaceAll("mask:url('assets/ui/pigment-wash.svg')","mask:var(--wash-mask)").replaceAll('mask:url("assets/ui/pigment-wash.svg")','mask:var(--wash-mask)').replaceAll("mask:url('assets/ui/check-mark.svg')","mask:var(--check-mask)").replaceAll('mask:var(--divider)','mask:var(--rule-mask)');
css+='\n/* Embedded drawing masks */\n:root{--wash-mask:'+mask('pigment-wash.svg')+';--check-mask:'+mask('check-mark.svg')+';--rule-mask:'+mask('divider-ink.svg')+';--checkbox:url("assets/ui/checkbox-ink.svg")}\n:root[data-theme=dark]{--checkbox:url("assets/ui/checkbox-chalk.svg")}\n.check-art{border:0;border-image:none;background:var(--checkbox) center/100% 100% no-repeat}\n.check-art::before{left:3px;top:1px;width:28px;height:28px}\n.ink-button.square::after{border-image-source:var(--checkbox);border-image-slice:10;border-image-width:10px}\n';
fs.writeFileSync(p,css);console.log('Dessins : dimensions intrinsèques fixées, masques SVG embarqués pour lecture locale.');
