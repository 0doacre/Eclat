"use strict";
(() => {
  const $ = selector => document.querySelector(selector), $$ = selector => [...document.querySelectorAll(selector)];
  const state = { view:"menu", dark:false, large:false, stock:{ bois:122, fibre:75, caillou:40 } };
  const say = text => { $('#status').textContent = text; };
  function view(next) {
    state.view = next;
    $('#menuPage').hidden = next === 'domaine'; $('#domainPage').hidden = next !== 'domaine';
    $('#gamePage').hidden = next === 'composants'; $('#componentSheet').hidden = next !== 'composants';
    $('.work-area').classList.toggle('components-view', next === 'composants');
    $$('[data-view]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.view === next)));
    $('#pageSwitch').setAttribute('aria-label', next === 'domaine' ? 'Afficher le menu' : 'Afficher le Domaine');
    say(next === 'composants' ? 'Le cadre, le bouton, les filets et le lavis sont de vrais fichiers SVG réutilisés.' : 'Prototype de présentation · aucune connexion au moteur du jeu.');
  }
  function theme(dark) {
    state.dark = dark; document.documentElement.dataset.theme = dark ? 'dark' : 'light';
    $('#themeButton').setAttribute('aria-pressed', String(dark)); $('#themeButton').textContent = dark ? 'Thème clair' : 'Thème sombre'; $('#darkThemeCheck').checked = dark;
  }
  $$('[data-view]').forEach(b => b.addEventListener('click', () => view(b.dataset.view)));
  $('#resumeButton').addEventListener('click', () => view('domaine')); $('#backToMenu').addEventListener('click', () => view('menu'));
  $('#pageSwitch').addEventListener('click', () => view(state.view === 'domaine' ? 'menu' : 'domaine'));
  $('#themeButton').addEventListener('click', () => theme(!state.dark)); $('#darkThemeCheck').addEventListener('change', e => theme(e.target.checked));
  $$('.large-text-check').forEach(c => c.addEventListener('change', e => { state.large = e.target.checked; document.documentElement.dataset.large = String(state.large); $$('.large-text-check').forEach(input => input.checked = state.large); }));
  const tabs = $$('.ink-tabs [role=tab]');
  function tab(target, focus=false) {
    tabs.forEach(t => { const active=t===target; t.setAttribute('aria-selected',String(active)); t.tabIndex=active?0:-1; $('#'+t.getAttribute('aria-controls')).hidden=!active; });
    if(focus)target.focus();
  }
  tabs.forEach(t => { t.addEventListener('click', () => tab(t)); t.addEventListener('keydown', e => { let index=tabs.indexOf(t); if(e.key==='ArrowRight')index=(index+1)%tabs.length;else if(e.key==='ArrowLeft')index=(index+tabs.length-1)%tabs.length;else if(e.key==='Home')index=0;else if(e.key==='End')index=tabs.length-1;else return;e.preventDefault();tab(tabs[index],true); }); });
  $('#ambienceVolume').addEventListener('input', e => { $('#volumeValue').textContent = e.target.value+' %'; });
  $('#saveButton').addEventListener('click', () => say('Réglages mémorisés pour cette session de la maquette. Aucune partie du jeu n’a été enregistrée.'));
  $('#helpButton').addEventListener('click', () => $('#helpDialog').showModal());
  $$('[data-harvest]').forEach(b => b.addEventListener('click', () => {
    const id = b.dataset.harvest; state.stock[id]++; $('[data-stock='+id+']').textContent=state.stock[id];
    const img=b.closest('.resource-row').querySelector('img');img.classList.remove('hit');void img.offsetWidth;img.classList.add('hit');
    say(({bois:'Bois',fibre:'Fibres',caillou:'Pierre'})[id]+' +1 · simulation locale de la récolte.');
  }));
  $('#progressDemo').addEventListener('input', e => { const n=Number(e.target.value);$('#progressValue').textContent=n+' %';$('#progressFill').style.width=n+'%';$('.ink-progress').setAttribute('aria-valuenow',String(n)); });
})();
