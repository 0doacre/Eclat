# Éclat — Interface dessinée, première base fonctionnelle

## Direction retenue

Le Carnet du Semeur possède désormais un premier vocabulaire d'interface dessiné : contours à l'encre, légers dédoublements du trait, filets, cases cochées et lavis sous les actions. L'irrégularité reste discrète. Les illustrations de matières et de sources conservent leurs couleurs naturelles.

Le moodboard `moodboard-interface-dessinee-v1.png` a été produit avec l'outil intégré imagegen, à partir des études de menus et de la Lisière et d'illustrations du lot Âge du Bois. Son prompt est fourni dans `prompt-imagegen.txt`. C'est une planche d'intention. Pour les assets du jeu, les PNG originaux et les tracés SVG du prototype sont les fichiers à reprendre ; ne pas découper le texte ou les boutons dans la planche.

## Ouvrir et éprouver

Ouvrir **`index.html`** dans un navigateur. Le prototype fonctionne aussi depuis le système de fichiers : les masques de dessin nécessaires sont embarqués dans le CSS pour cette raison. Aucune installation et aucun service distant ne sont nécessaires.

- **Menu** : action Reprendre, vrais onglets Jeu / Affichage / Audio, cases de réglages, grand texte et fenêtre d'aide.
- **Domaine** : arbre, plantes et affleurement avec une récolte locale ; matières en Réserve ; panier comme équipement.
- **Composants** : états de boutons, case à cocher, exemple de progression et cadre extensible.
- Le bouton de thème permet de comparer le papier clair et la veillée.

Les stocks et les réglages sont des valeurs locales de démonstration. Le prototype n'est connecté ni au moteur, ni aux sauvegardes, ni aux sons du jeu. Le bouton Sauvegarder indique explicitement qu'aucune partie du jeu n'est enregistrée.

## Ce qui est déjà construit

- **Dix fichiers SVG éditables** dans `assets/ui/` : cadres clair/sombre, boutons clair/sombre, filets clair/sombre, lavis, marque de coche et contours de cases clair/sombre.
- Cadres et boutons assemblés avec des **bordures en neuf parties**. Les coins conservent leurs dimensions tandis que les sections centrales s'adaptent à la taille du composant.
- Lavis et marques séparés du texte. Les éléments interactifs restent des boutons, cases, onglets, curseurs et dialogues natifs.
- Deux familles typographiques déjà utilisées par Éclat, avec les fichiers locaux et les crédits du dépôt d'origine.
- Huit illustrations PNG du premier lot, réutilisées sans retouche : bois, fibres, pierre, corde, panier et trois sources de récolte.

Le CSS du prototype précise les dimensions de découpe. `qa/prepare-skins.js` fixe les dimensions intrinsèques des SVG et embarque les petits masques dans le CSS ; il faut le relancer si l'on modifie les SVG correspondants. Les illustrations ne sont jamais déformées pour remplir un bouton ou une case.

## Intégration à poursuivre dans Vivant

Reprendre cette base après ton intégration en cours des illustrations du premier âge. Conserver ton travail déjà effectué : ce lot ajoute l'habillage dessiné et une référence de composition.

1. Créer des composants de présentation réutilisables pour fenêtre, bouton, onglet, case et filet. Les tracés sont des ressources de dessin, pas une image pleine page contenant des zones cliquables.
2. Raccorder ces composants au menu existant avant de les généraliser. Les libellés, la progression, les paramètres et la sauvegarde restent ceux du moteur.
3. Reporter la même grammaire dans le Domaine : place aux illustrations, séparateurs calmes et actions lisibles. Le prototype ne reproduit pas tout le contenu de l'écran réel ; conserver les débits, extracteurs, maîtrises et passages existants.
4. Garder les contrôles natifs, les noms accessibles, le focus, le clavier et les cibles tactiles. Les dessins et les effets ne doivent jamais intercepter les événements ni provoquer de déplacement de la mise en page.
5. Décliner progressivement sur l'Atelier et le Carnet. Stabiliser les conventions de lecture ; faire évoluer le support et les documents avec les âges, sans perdre la même main du Semeur.
6. Préserver les autres styles du jeu. L'essai s'applique d'abord à Vivant.
7. Optimiser seulement les variantes d'illustrations réellement utilisées. Ne pas mettre les PNG maîtres, les captures, l'archive ou le moodboard dans le cache du jeu. Recalculer le service worker selon le workflow du dépôt.
8. Vérifier les deux thèmes, les petits écrans, les textes longs et les états réels ; lancer ensuite les tests du jeu et les contrôles de boutons appropriés.

## État de la proposition

Cette v1 établit les composants, leurs interactions et leur adaptation aux tailles. Le grain pictural et les variations de trait pourront encore être affinés à partir du moodboard. Le lavis du prototype est une forme SVG légère et extensible, pas une texture haute résolution. C'est volontairement une base éditable pour travailler, pas une prétention de reproduction pixel par pixel de la planche.

## Vérifications déjà réalisées

`qa/check-prototype.js` vérifie les interactions et produit les captures dans `qa/`. Le rapport est `qa/report.json` : 120 contrôles sur 320, 390 et 980 px, en clair et sombre. Sont vérifiés : chargement des images, absence de débordement, cibles des boutons/onglets/cases, navigation clavier, sélection d'un seul panneau d'onglet, grand texte, valeurs des curseurs, aide, récolte locale et message de sauvegarde de démonstration.

Ces contrôles concernent le prototype autonome. Les tests de non-régression du jeu restent à effectuer après son intégration.
